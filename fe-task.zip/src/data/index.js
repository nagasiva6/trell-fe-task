const data = {
    f1 : {
        f2 : {
            f5 : {
                f6 : {},
            },
            f7: {
                f8: {
                    f9: {}
                }
            },
            f10:{}
        },
        f3 : null,
    },
    f4 : {
        f2 : {
            f5 : {
                f6 : {},
            },
            f7: {
                f8: {
                    f9: {}
                }
            },
            f10:{}
        },
    },
}

export default data;
